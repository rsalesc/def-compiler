#pragma once

#include <map>
#include <vector>
#include <string>
#include <typeinfo>
#include <memory>
#include <iostream>

using namespace std;

struct ScopeValue{
  virtual bool is_func() const { return false; }
  virtual bool is_int() const { return false; }
};

struct ScopeFunc : public ScopeValue {
  bool returns;
  ScopeFunc(bool returns = false) : returns(returns){}
  bool returns_int() const { return returns; }
  bool returns_void() const { return !returns; }
  bool is_func() const override{
    return true;
  }
};

struct ScopeInt : public ScopeValue {
  bool is_int() const override{
    return true;
  }
};

struct Scope{
  bool inside_loop, inside_int;
  map<string, shared_ptr<ScopeValue>> table;

  Scope(){
    inside_loop = inside_int = false;
  }

  bool check(string s) { return table.count(s); }
  shared_ptr<ScopeValue> & get (string s) { return table[s]; }
};

struct ScopeStack{
  vector<Scope> st;

  shared_ptr<ScopeValue> & declare(string var){
    if(st.back().check(var))
      throw runtime_error("name " + var + " was declared before");

    return st.back().get(var);
  }

  ScopeFunc & declare_func(string var, bool returns_int = false){
    return *dynamic_pointer_cast<ScopeFunc>(this->declare(var) = make_shared<ScopeFunc>(returns_int));
  }

  ScopeInt & declare_int(string var){
    return *dynamic_pointer_cast<ScopeInt>(this->declare(var) = make_shared<ScopeInt>());
  }

  shared_ptr<ScopeValue> get(string var){
    for(int i = (int)st.size()-1; i >= 0; i--){
      if(st[i].check(var))
        return st[i].get(var);
    }

    throw runtime_error("name " + var + " not declared in this scope");
  }

  ScopeFunc & get_func(string var){
    shared_ptr<ScopeFunc> res = 0;
    try{
      res = dynamic_pointer_cast<ScopeFunc>(this->get(var));
    } catch(std::exception & e){
      throw runtime_error("name " + var + " not declared in this scope");
    }

    if(res == 0)
      throw runtime_error("name " + var + " was declared before but is not a function");
    return *res;
  }

  ScopeInt & get_int(string var){
    shared_ptr<ScopeInt> res = 0;
    try{
      res = dynamic_pointer_cast<ScopeInt>(this->get(var));
    } catch(std::exception & e){
      throw runtime_error("name " + var + " not declared in this scope");
    }
    if(res == 0)
      throw runtime_error("name " + var + " was declared before but is not an int");
    return *res;

  }

  void push(){
    st.emplace_back();
  }

  void push_int(){
    push();
    st.back().inside_int = true;
  }

  void push_void(){
    push();
  }

  void push_loop(){
    push();
    st.back().inside_loop = true;
  }

  void pop(){
    st.pop_back();
  }

  bool is_int() const {
    for(const auto & p : st)
      if(p.inside_int)
        return true;
    return false;
  }

  bool is_loop() const {
    for(const auto & p : st){
      if(p.inside_loop)
        return true;
    }

    return false;
  }
};
